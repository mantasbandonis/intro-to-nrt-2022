// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

#include <stdint.h>
#include <stddef.h>
#include <stdatomic.h>

typedef struct _SPSCQueue {
    void *mappedData_;
    char *alignedRaw_;
    char *arrayBase_;
    // consumer owns readPtr and writeCachePtr
    atomic_long *readAtomicPtr_;
    long *readPtr_;
    long *writeCachePtr_;

    // producer owns writePtr and readCachePtr
    atomic_long *writeAtomicPtr_;
    long *writePtr_;
    long *readCachePtr_;

    atomic_long *finishAtomicPtr_;

    int capacity_;
    int mask_;

    int mmapLen_;
} SPSCQueue;

SPSCQueue *create_queue(const char *fileName, size_t len, int reset);

void write_data(SPSCQueue *queue, const char *val, size_t offset, size_t len);

int read_data(SPSCQueue *queue, void *buf, size_t offset, size_t len);

int available(SPSCQueue *queue);

long isFinished(SPSCQueue *queue);

void mark_finish(SPSCQueue *queue);

int open_mmap_file_rw(const char *filename, size_t bytesize);

int roundToPowerOfTwo(int value);

long roundTo4096(long value);

long align(long value, int alignment);

int numberOfLeadingZeros(int i);

long nextWrap(SPSCQueue *queue, long v);

long getReadPlain(SPSCQueue *queue);

long getRead(SPSCQueue *queue);

long getWritePlain(SPSCQueue *queue);

long getWrite(SPSCQueue *queue);

long getReadCache(SPSCQueue *queue);

long getWriteCache(SPSCQueue *queue);

void setRead(SPSCQueue *queue, long value);

void setWrite(SPSCQueue *queue, long value);

void setReadCache(SPSCQueue *queue, long value);

void setWriteCache(SPSCQueue *queue, long value);

long getLong(long *ptr);

long getLongVolatile(atomic_long *ptr);

void putLong(long *ptr, long value);

void putOrderedLong(atomic_long *ptr, long value);

void putLongVolatile(atomic_long *ptr, long value);

void close_queue(SPSCQueue *queue);
