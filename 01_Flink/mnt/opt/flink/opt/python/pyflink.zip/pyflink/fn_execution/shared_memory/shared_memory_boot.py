#!/usr/bin/env python
#################################################################################
#  Licensed to the Apache Software Foundation (ASF) under one
#  or more contributor license agreements.  See the NOTICE file
#  distributed with this work for additional information
#  regarding copyright ownership.  The ASF licenses this file
#  to you under the Apache License, Version 2.0 (the
#  "License"); you may not use this file except in compliance
#  with the License.  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
# limitations under the License.
################################################################################
from pyflink.fn_execution.sharedmemory import spsc_queue
from pyflink.fn_execution import coders, flink_fn_execution_pb2
from pyflink.fn_execution.sharedmemory import shared_memory_operations


def main():
    with open('/tmp/test.txt', 'a') as fd:
        fd.write("start" + '\n')
    size = (1 << 20)
    send_queue = spsc_queue.PySpscQueue("/tmp/send".encode("utf-8"), size * 10, False)
    receive_queue = spsc_queue.PySpscQueue("/tmp/receive".encode("utf-8"), size * 10, False)
    with open('/tmp/test.txt', 'a') as fd:
        fd.write("start second" + '\n')
    data = spsc_queue.read_bytes(send_queue)
    function_urn = data.decode('utf-8')
    with open('/tmp/test.txt', 'a') as fd:
        fd.write("func urn " + str(function_urn) + '\n')
    data = spsc_queue.read_bytes(send_queue)
    serialized_fn = flink_fn_execution_pb2.UserDefinedFunctions()
    serialized_fn.ParseFromString(data)
    with open('/tmp/test.txt', 'a') as fd:
        fd.write("func " + str(serialized_fn) + '\n')
    data = spsc_queue.read_bytes(send_queue)
    coder_urn = data.decode('utf-8')
    with open('/tmp/test.txt', 'a') as fd:
        fd.write("coder urn " + str(coder_urn) + '\n')
    data = spsc_queue.read_bytes(send_queue)
    input_schema = flink_fn_execution_pb2.Schema()
    input_schema.ParseFromString(data)
    data = spsc_queue.read_bytes(send_queue)
    output_schema = flink_fn_execution_pb2.Schema()
    output_schema.ParseFromString(data)
    with open('/tmp/test.txt', 'a') as fd:
        fd.write(str(input_schema) + '\n')
        fd.write(str(output_schema) + '\n')
    input_coder = coders.FlattenRowCoder.from_schema_proto(input_schema)
    output_coder = coders.FlattenRowCoder.from_schema_proto(output_schema)
    with open('/tmp/test.txt', 'a') as fd:
        fd.write(str(input_coder) + '\n')
        fd.write(str(output_coder) + '\n')
    operation = shared_memory_operations.ScalarFunctionOperation(serialized_fn, input_coder,
                                                                 output_coder, send_queue,
                                                                 receive_queue)
    operation.process()


if __name__ == "__main__":
    main()
