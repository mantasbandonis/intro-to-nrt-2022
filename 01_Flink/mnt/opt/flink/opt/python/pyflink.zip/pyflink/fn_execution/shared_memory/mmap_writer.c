// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <pthread.h>

#if defined(__APPLE__) || defined(__MACH__)
#define pthread_yield() pthread_yield_np()
#endif

#include <Python.h>

#include "mmap_writer.h"

#define CACHE_LINE_SIZE 64
#ifndef MIN
#define MIN(a, b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a < _b ? _a : _b; })
#endif /* MIN */

SPSCQueue *create_queue(const char *fileName, size_t len, int reset) {
    SPSCQueue *queue = malloc(sizeof(SPSCQueue));
    int fd;
    int capacity = roundToPowerOfTwo(len);
    int requiredBufferSize = 4 * CACHE_LINE_SIZE + roundToPowerOfTwo(capacity);
    int mapSize = roundTo4096(requiredBufferSize);
    if (reset) {
        fd = open_mmap_file_rw(fileName, mapSize);
    } else {
        fd = open(fileName, O_RDWR);
    }
    assert(fd != -1);
    void *mappedData = mmap(NULL, mapSize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    assert(mappedData != MAP_FAILED);
    close(fd);
    queue->mappedData_ = mappedData;
    long alignedPtr = align((long) mappedData, CACHE_LINE_SIZE);
    queue->alignedRaw_ = (char *) alignedPtr;
    queue->arrayBase_ = (char *) (alignedPtr + 4 * CACHE_LINE_SIZE);

    queue->readAtomicPtr_ = (atomic_long *) alignedPtr;
    queue->readPtr_ = (long *) alignedPtr;
    queue->writeCachePtr_ = (long *) (alignedPtr + 8);

    queue->writeAtomicPtr_ = (atomic_long *) (alignedPtr + 2 * CACHE_LINE_SIZE);
    queue->writePtr_ = (long *) (alignedPtr + 2 * CACHE_LINE_SIZE);
    queue->readCachePtr_ = (long *) (alignedPtr + 2 * CACHE_LINE_SIZE + 8);

    queue->finishAtomicPtr_ = (atomic_long *) (alignedPtr + 3 * CACHE_LINE_SIZE);
    queue->mmapLen_ = mapSize;
    if (reset) {
        queue->capacity_ = capacity;
        memset(mappedData, 0, mapSize);
        putLongVolatile((atomic_long *) (alignedPtr + CACHE_LINE_SIZE), (long) capacity);
    } else {
        queue->capacity_ = *((long *) (alignedPtr + CACHE_LINE_SIZE));
    }
    queue->mask_ = queue->capacity_ - 1;
    return queue;
}

void write_data(SPSCQueue *queue, const char *val, size_t offset, size_t len) {
    char *q;

    long currentWrite = getWritePlain(queue);
    long readWatermark = currentWrite - (queue->capacity_ - len);
    while (getReadCache(queue) <= readWatermark) {
        setReadCache(queue, getRead(queue));
        if (getReadCache(queue) <= readWatermark) {
            pthread_yield();
        }
    }
    int written = 0;
    while (written < len) {
        long nextWriteWrap = nextWrap(queue, currentWrite);
        int bytesToWrite = MIN(len - written, nextWriteWrap - currentWrite);
        q = (char *) ((void *) (queue->arrayBase_) + (currentWrite & queue->mask_));
        memcpy(q, val + offset + written, bytesToWrite);
        currentWrite += bytesToWrite;
        written += bytesToWrite;
        setWrite(queue, currentWrite);
    }
}

int read_data(SPSCQueue *queue, void *buf, size_t offset, size_t len) {
    int hasRead = 0;
    char *q;
    while (hasRead < len) {
        long currentRead = getReadPlain(queue);
        while (getWriteCache(queue) <= currentRead) {
            setWriteCache(queue, getWrite(queue));
            if (getWriteCache(queue) <= currentRead) {
                pthread_yield_np();
            }
        }
        long nextReadWrap = nextWrap(queue, currentRead);
        long writeCache = getWriteCache(queue);
        int avail = MIN(writeCache - currentRead, nextReadWrap - currentRead);
        int bytesToRead = MIN(avail, len - hasRead);
        q = (char *) ((void *) (queue->arrayBase_) + (currentRead & queue->mask_));
        memcpy(buf + offset + hasRead, q, bytesToRead);
        setRead(queue, currentRead + bytesToRead);
        hasRead += bytesToRead;
    }
    return hasRead;
}

int available(SPSCQueue *queue) {
    long currentRead = getReadPlain(queue);
    long writeCache = getWriteCache(queue);
    if (currentRead >= writeCache) {
        setWriteCache(queue, getWrite(queue));
        writeCache = getWriteCache(queue);
    }
    int avail = writeCache - currentRead;
    if (avail > 0) {
        return avail;
    }
    return 0;
}

long isFinished(SPSCQueue *queue) {
    return getLongVolatile(queue->finishAtomicPtr_);
}

void mark_finish(SPSCQueue *queue) {
    putLongVolatile(queue->finishAtomicPtr_, 1L);
}

int open_mmap_file_rw(const char *filename, size_t bytesize) {
    int fd;
    int result;
    struct stat stat;

    /* Open a file for writing.
     * * - Creating the file if it doesn't exist.
     * *
     * * Note: "O_WRONLY" mode is not sufficient when mmaping.
     * */

    fd = open(filename, O_RDWR | O_CREAT, (mode_t) 0666);
    if (fd == -1) {
        PyErr_SetFromErrnoWithFilename(PyExc_OSError,
                                       "Error opening file for writing");
        return -1;
    }

    if (fstat(fd, &stat)) {
        PyErr_SetFromErrnoWithFilename(PyExc_OSError,
                                       "Error calling fstat");
        close(fd);
        return -1;
    }

    if (stat.st_size < bytesize) {
        /* Stretch the file size to the size of the (mmapped) array of
         * ints
         * */
        result = lseek(fd, bytesize - 1, SEEK_SET);
        if (result == -1) {
            PyErr_SetFromErrnoWithFilename(PyExc_OSError,
                                           "Error calling lseek() to 'stretch' the file");
            close(fd);
            return -1;
        }

        /* Something needs to be written at the end of the file to
         * * have the file actually have the new size.
         * * Just writing an empty string at the current file position
         * will do.
         * *
         * * Note:
         * * - The current position in the file is at the end of the
         * stretched
         * * file due to the call to lseek().
         * * - An empty string is actually a single '\0' character, so a
         * zero-byte
         * * will be written at the last byte of the file.
         * */
        result = write(fd, "", 1);
        if (result != 1) {
            close(fd);
            PyErr_SetFromErrnoWithFilename(PyExc_OSError,
                                           "Error writing last byte of the file");
            return -1;
        }
    }

    return fd;
}

int roundToPowerOfTwo(int value) {
    return 1 << (32 - numberOfLeadingZeros(value - 1));
}

long roundTo4096(long value) {
    return (value + 0xfffL) & ~0xfffL;
}

long align(long value, int alignment) {
    return (value + (alignment - 1)) & -alignment;
}

int numberOfLeadingZeros(int i) {
    if (i == 0)
        return 32;
    int n = 1;
    if (((unsigned int) i) >> 16 == 0) {
        n += 16;
        i <<= 16;
    }
    if (((unsigned int) i) >> 24 == 0) {
        n += 8;
        i <<= 8;
    }
    if (((unsigned int) i) >> 28 == 0) {
        n += 4;
        i <<= 4;
    }
    if (((unsigned int) i) >> 30 == 0) {
        n += 2;
        i <<= 2;
    }
    n -= (((unsigned int) i) >> 31);
    return n;
}

long nextWrap(SPSCQueue *queue, long v) {
    if ((v & queue->mask_) == 0) {
        return v + queue->capacity_;
    }
    return align(v, queue->capacity_);
}

long getReadPlain(SPSCQueue *queue) {
    return getLong(queue->readPtr_);
}

long getRead(SPSCQueue *queue) {
    return getLongVolatile(queue->readAtomicPtr_);
}

long getWritePlain(SPSCQueue *queue) {
    return getLong(queue->writePtr_);
}

long getWrite(SPSCQueue *queue) {
    return getLongVolatile(queue->writeAtomicPtr_);
}

long getReadCache(SPSCQueue *queue) {
    return getLong(queue->readCachePtr_);
}

long getWriteCache(SPSCQueue *queue) {
    return getLong(queue->writeCachePtr_);
}

void setRead(SPSCQueue *queue, long value) {
    putOrderedLong(queue->readAtomicPtr_, value);
}

void setWrite(SPSCQueue *queue, long value) {
    putOrderedLong(queue->writeAtomicPtr_, value);
}

void setReadCache(SPSCQueue *queue, long value) {
    putLong(queue->readCachePtr_, value);
}

void setWriteCache(SPSCQueue *queue, long value) {
    putLong(queue->writeCachePtr_, value);
}

long getLong(long *ptr) {
    return *ptr;
}

long getLongVolatile(atomic_long *ptr) {
    return atomic_load(ptr);
}

void putLong(long *ptr, long value) {
    *ptr = value;
}

void putOrderedLong(atomic_long *ptr, long value) {
    atomic_store_explicit(ptr, value, memory_order_release);
}

void putLongVolatile(atomic_long *ptr, long value) {
    atomic_store(ptr, value);
}

void close_queue(SPSCQueue *queue) {
    int rc = munmap(queue->mappedData_, queue->mmapLen_);
    if (rc != 0) {
        PyErr_SetFromErrnoWithFilename(PyExc_OSError,
                                       "Error un-mmapping the file");
    }
}
